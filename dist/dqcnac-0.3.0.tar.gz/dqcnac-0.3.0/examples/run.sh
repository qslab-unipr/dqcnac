python example.py
