import csv
import re


def load_blocks(filepath):
    """Parse ordered (block_num, routine_name) from the program header."""
    blocks = []
    cur = None
    with open(filepath) as f:
        for line in f:
            if line.startswith("SUBROUTINE "):
                break
            m = re.match(r"\^b(\d+)", line)
            if m:
                cur = int(m.group(1))
            r = re.search(r"run_subroutine\([^)]*\)\s*:\s*(\S+)", line)
            if r and cur is not None:
                blocks.append((cur, r.group(1)))
                cur = None
    return blocks


def load_subroutines(filepath):
    """
    Parse every SUBROUTINE definition.
    Returns dict: name -> {'uses': set(int), 'netqasm': [str]}
    """
    subs = {}
    cur_name = None
    cur_uses = set()
    cur_netqasm = []
    in_netqasm = False

    with open(filepath) as f:
        for line in f:
            s = line.strip()
            if s.startswith("SUBROUTINE "):
                cur_name = s.split()[1]
                cur_uses = set()
                cur_netqasm = []
                in_netqasm = False
            elif cur_name:
                if s.startswith("uses:"):
                    cur_uses = set(
                        int(x) for x in s[5:].split(",") if x.strip().isdigit()
                    )
                elif s == "NETQASM_START":
                    in_netqasm = True
                elif s == "NETQASM_END":
                    subs[cur_name] = {"uses": cur_uses, "netqasm": list(cur_netqasm)}
                    cur_name = None
                    in_netqasm = False
                elif in_netqasm and s:
                    cur_netqasm.append(s)
    return subs


def gate_op(netqasm_line):
    """Return the gate mnemonic from a NetQASM instruction, or None for non-gate lines."""
    # Skip set/load/store/bez/bez/jmp/ret register moves
    non_gates = {
        "set",
        "load",
        "store",
        "bez",
        "bne",
        "jmp",
        "ret",
        "mov",
        "add",
        "sub",
    }
    parts = netqasm_line.split()
    if not parts:
        return None
    op = parts[0].lower()
    if op in non_gates:
        return None
    return op


def check_clean_window(filepath):
    """
    For every cat_ent/cat_disent bracket on qubit 256:
      - Find all cz_routines on q256 inside the bracket, collect their partner qubits.
      - The 'watched set' = {256} | {all partner qubits in this bracket}.
      - Check that NO other routine inside the bracket touches any watched qubit,
        except for:
          * the cat_ent / cat_disent routines themselves (they are allowed on q256)
          * cz_routines that use q256 (already expected)
    Reports any unexpected routine that touches a watched qubit.
    """
    blocks = load_blocks(filepath)
    subs = load_subroutines(filepath)
    uses = {n: s["uses"] for n, s in subs.items()}

    print(f"Loaded {len(blocks)} blocks, {len(subs)} subroutines from {filepath}\n")

    violations = []
    bracket_summary = []

    bracket_id = 0
    state = "CLOSED"
    open_block = open_name = None
    window_events = []  # all (bnum, name) inside current bracket

    for bnum, name in blocks:
        q256 = 256 in uses.get(name, set())
        is_ent = q256 and "catent" in name and "catdisent" not in name
        is_disent = q256 and "catdisent" in name

        if is_ent:
            bracket_id += 1
            state = "OPEN"
            open_block, open_name = bnum, name
            window_events = []

        elif is_disent and state == "OPEN":
            # --- analyse this bracket ---
            disent_block = bnum
            disent_name = name

            # collect partner qubits from cz/cx on q256 inside this bracket
            partner_qubits = set()
            for eb, en in window_events:
                if bool(re.search(r"c[xz]_routine", en)) and 256 in uses.get(en, set()):
                    partner_qubits |= uses.get(en, set()) - {256}

            watched = frozenset({256} | partner_qubits)

            # now check every block inside the bracket
            bracket_viols = []
            for eb, en in window_events:
                touched = uses.get(en, set()) & watched
                if not touched:
                    continue
                is_czx_256 = bool(re.search(r"c[xz]_routine", en)) and 256 in uses.get(
                    en, set()
                )
                if is_czx_256:
                    continue  # expected — this IS the cz on q256
                # anything else touching a watched qubit is unexpected
                bracket_viols.append(
                    {
                        "bracket_id": bracket_id,
                        "ent_block": open_block,
                        "disent_block": disent_block,
                        "block": eb,
                        "routine": en,
                        "touched_watched": sorted(touched),
                        "routine_uses": sorted(uses.get(en, set())),
                    }
                )

            bracket_summary.append(
                {
                    "id": bracket_id,
                    "ent_block": open_block,
                    "ent_name": open_name,
                    "disent_block": disent_block,
                    "disent_name": disent_name,
                    "partners": sorted(partner_qubits),
                    "violations": len(bracket_viols),
                }
            )
            violations.extend(bracket_viols)
            state = "CLOSED"
            open_block = open_name = None

        elif state == "OPEN":
            window_events.append((bnum, name))

    # --- report ---
    total_v = len(violations)
    print(f"{'ID':>4}  {'ent':>7}  {'disent':>7}  {'partners':>50}  {'violations':>10}")
    print("-" * 90)
    for g in bracket_summary:
        partners_str = str(g["partners"])
        print(
            f"{g['id']:>4}  {g['ent_block']:>7}  {g['disent_block']:>7}  {partners_str:>50}  {g['violations']:>10}"
        )
    print("-" * 90)
    print(f"\nTotal violations across all brackets: {total_v}")

    if total_v == 0:
        print("\n✅ Clean: no routine inside any cat_ent/cat_disent scope touches")
        print("   qubit 256 or any cz-partner qubit, except the expected cz routines.")
    else:
        print(f"\n✗ {total_v} unexpected routine(s) found inside brackets:")
        for v in violations:
            print(
                f"  bracket={v['bracket_id']}  b{v['block']}  {v['routine']}"
                f"  uses={v['routine_uses']}  touched_watched={v['touched_watched']}"
            )

    # write violations CSV
    out = filepath.replace(".iqoala", "_clean_window_violations.csv")
    with open(out, "w", newline="") as f:
        fieldnames = [
            "bracket_id",
            "ent_block",
            "disent_block",
            "block",
            "routine",
            "touched_watched",
            "routine_uses",
        ]
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for v in violations:
            w.writerow({k: str(v[k]) for k in fieldnames})
    print(f"\nViolations CSV written to: {out}")


if __name__ == "__main__":
    import sys

    for path in sys.argv[1:]:
        print("=" * 90)
        check_clean_window(path)
        print()
