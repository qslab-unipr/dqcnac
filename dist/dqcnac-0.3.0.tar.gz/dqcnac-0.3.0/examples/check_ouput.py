import csv
import re


def load_blocks(filepath):
    """Parse ordered block->subroutine calls from the program header."""
    blocks = []
    cur = None
    with open(filepath) as f:
        for line in f:
            if line.startswith("SUBROUTINE "):
                break
            m = re.match(r"\^b(\d+)", line)
            if m:
                cur = int(m.group(1))
            r = re.search(r"run_subroutine\([^)]*\)\s*:\s*(\S+)", line)
            if r and cur is not None:
                blocks.append((cur, r.group(1)))
                cur = None
    return blocks


def load_subroutine_uses(filepath):
    """Parse the 'uses:' qubit set for every SUBROUTINE definition."""
    uses = {}
    cur_name = None
    with open(filepath) as f:
        for line in f:
            s = line.strip()
            if s.startswith("SUBROUTINE "):
                cur_name = s.split()[1]
            elif cur_name and s.startswith("uses:"):
                qs = set(int(x) for x in s[5:].split(",") if x.strip().isdigit())
                uses[cur_name] = qs
                cur_name = None
    return uses


def check_bracketing(filepath):
    blocks = load_blocks(filepath)
    uses = load_subroutine_uses(filepath)

    print(f"Loaded {len(blocks)} blocks and {len(uses)} subroutines from {filepath}")

    # --- classify each block that touches qubit 256 ---
    violations = []
    bracket_summary = []
    csv_rows = []

    bracket_id = 0
    state = "CLOSED"
    open_block = open_name = None
    cz_in_bracket = []

    for bnum, name in blocks:
        q256 = 256 in uses.get(name, set())
        is_ent = q256 and "catent" in name and "catdisent" not in name
        is_disent = q256 and "catdisent" in name
        is_czx = q256 and bool(re.search(r"c[xz]_routine", name))

        if is_ent:
            if state == "OPEN":
                violations.append(
                    f"NESTED_CAT_ENT at b{bnum} ({name}) — "
                    f"bracket {bracket_id} (opened at b{open_block}) still open"
                )
            else:
                bracket_id += 1
                state = "OPEN"
                open_block, open_name = bnum, name
                cz_in_bracket = []

        elif is_disent:
            if state == "CLOSED":
                violations.append(f"DISENT_WITHOUT_ENT at b{bnum} ({name})")
            else:
                bracket_summary.append(
                    {
                        "id": bracket_id,
                        "ent_block": open_block,
                        "ent_name": open_name,
                        "disent_block": bnum,
                        "disent_name": name,
                        "cz_cx_count": len(cz_in_bracket),
                    }
                )
                for cb, cn, cq in cz_in_bracket:
                    csv_rows.append(
                        {
                            "bracket_id": bracket_id,
                            "cat_ent_block": open_block,
                            "cat_ent_routine": open_name,
                            "cat_disent_block": bnum,
                            "cat_disent_routine": name,
                            "cz_cx_block": cb,
                            "cz_cx_routine": cn,
                            "other_qubit": cq,
                        }
                    )
                state = "CLOSED"
                open_block = open_name = None

        elif is_czx:
            if state == "CLOSED":
                violations.append(f"CZX_OUTSIDE_BRACKET at b{bnum} ({name})")
            else:
                others = sorted(uses.get(name, set()) - {256})
                cz_in_bracket.append((bnum, name, others[0] if others else None))

    if state == "OPEN":
        violations.append(
            f"UNCLOSED_AT_EOF — bracket {bracket_id} opened at b{open_block} ({open_name})"
        )

    # --- print results ---
    print()
    if violations:
        print(f"VIOLATIONS ({len(violations)}):")
        for v in violations:
            print(f"  ✗ {v}")
    else:
        print("✅ No violations:")
        print("   - No nested cat_ent (every bracket closed before next opens)")
        print("   - No cat_disent without a preceding cat_ent")
        print("   - No cz/cx on qubit 256 outside a bracket")
        print("   - No unclosed bracket at end of program")

    total = sum(g["cz_cx_count"] for g in bracket_summary)
    print()
    print(f"{'ID':>4}  {'ent_block':>10}  {'disent_block':>12}  {'cz/cx count':>11}")
    print("-" * 50)
    for g in bracket_summary:
        print(
            f"{g['id']:>4}  {g['ent_block']:>10}  {g['disent_block']:>12}  {g['cz_cx_count']:>11}"
        )
    print("-" * 50)
    print(f"     {'TOTAL':>22}  {total:>11}")

    # --- write CSV ---
    if csv_rows:
        out = filepath.replace(".iqoala", "_cz_q256_brackets.csv")
        with open(out, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=csv_rows[0].keys())
            w.writeheader()
            w.writerows(csv_rows)
        print(f"\nCSV written to: {out}  ({len(csv_rows)} rows)")


if __name__ == "__main__":
    import sys

    for path in sys.argv[1:]:
        check_bracketing(path)
