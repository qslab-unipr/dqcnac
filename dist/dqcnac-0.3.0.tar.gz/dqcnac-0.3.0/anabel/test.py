import os
from typing import Dict
import yaml

from qiskit import QuantumCircuit, transpile

from dqcnac.network.network import Network, Node
from dqcnac.network_configuration.network_builder import simple_network
from dqcnac.remote_gate_scheduling.converters import from_qiskit_to_dag
from dqcnac.compiler.compile_manager import CompileManager


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    qasm_path = os.path.join(here, "CA_8.qasm")
    yaml_path = os.path.join(here, "2nodes_5cap_1comm.yaml")

    qc = QuantumCircuit.from_qasm_file(qasm_path)

    _ = transpile(qc, basis_gates=["x", "y", "z", "rx", "ry", "rz", "h", "cz"])

    circuit = from_qiskit_to_dag(qc)
    
    with open(yaml_path, "r"
    ) as stream:
        device_properties = yaml.load(stream, Loader=yaml.FullLoader)

    # network = Network()
    # nodes: Dict[str, Node] = {}

    n_nodes = 2  
    # for n in range(n_nodes):
    #     node = Node(
    #         str(n),
    #         device_properties["n_qubits"],
    #         device_properties["coupling"],
    #         device_properties["ebits"],
    #         device_properties["cap"],
    #     )
    #     nodes[str(n)] = node
    #     network.add_node(node)

    network = simple_network(n_nodes, device_properties, network_topology='complete')

    compiler = CompileManager(router='basic')
    (
        compiled_circuit,
        network_to_local,
        network_layout,
        regs_mapping,
        programs,
        measured,
    ) = compiler.run(circuit, network, use_tel=False, parse=True)

    print(circuit.num_gates())
    print(compiled_circuit.num_gates())

    out_dir = os.path.join(here, "iqoala", "CA", "NV", "A2A")
    os.makedirs(out_dir, exist_ok=True)

    cap = int(device_properties.get("cap", 0))
    ebits = len(device_properties.get("ebits", 0))

    VQ = 8

    for name, program in programs.items():
        out_name = f"2nodes_{name}_{VQ}VQ_{cap}cap_{ebits}ebits.iqoala"
        out_path = os.path.join(out_dir, out_name)
        print(f"Writing program to {out_path}")
        print(program)
        with open(out_path, "w") as f:
            f.write(program.serialize())


if __name__ == "__main__":
    main()
