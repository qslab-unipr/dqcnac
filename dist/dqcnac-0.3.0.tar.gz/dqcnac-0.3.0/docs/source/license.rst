License
=======

.. literalinclude:: ../../LICENSE
   :language: text