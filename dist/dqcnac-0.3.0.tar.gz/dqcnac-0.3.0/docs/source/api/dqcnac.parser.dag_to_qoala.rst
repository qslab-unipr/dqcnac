dqcnac.parser.dag\_to\_qoala module
===================================

.. automodule:: dqcnac.parser.dag_to_qoala
   :members:
   :undoc-members:
   :show-inheritance:
