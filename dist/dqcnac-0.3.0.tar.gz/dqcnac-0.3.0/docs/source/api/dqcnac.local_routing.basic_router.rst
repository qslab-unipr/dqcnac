dqcnac.local\_routing.basic\_router module
==========================================

.. automodule:: dqcnac.local_routing.basic_router
   :members:
   :undoc-members:
   :show-inheritance:
