dqcnac.nonlocal\_gate\_scheduling.nonlocal\_operations module
=============================================================

.. automodule:: dqcnac.nonlocal_gate_scheduling.nonlocal_operations
   :members:
   :undoc-members:
   :show-inheritance:
