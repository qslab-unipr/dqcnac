dqcnac.mapping.local\_mapping module
====================================

.. automodule:: dqcnac.mapping.local_mapping
   :members:
   :undoc-members:
   :show-inheritance:
