dqcnac.compiler.local\_manager module
=====================================

.. automodule:: dqcnac.compiler.local_manager
   :members:
   :undoc-members:
   :show-inheritance:
