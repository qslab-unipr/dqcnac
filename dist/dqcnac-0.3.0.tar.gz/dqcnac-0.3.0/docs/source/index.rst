.. DQC-NAC documentation master file, created by
   sphinx-quickstart on Thu Feb 26 10:04:55 2026.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

DQC-NAC documentation
=====================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   api
   license

